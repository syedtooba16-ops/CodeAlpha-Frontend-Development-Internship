# CodeAlpha Frontend Development Internship

This repository contains all four frontend development tasks completed for the **CodeAlpha Internship Program**.

## 📋 Project List

1. **Image Gallery**
   - Built with HTML, CSS, and JavaScript.
   - Features responsive design, category filters, hover effects, and a lightbox view.

2. **Calculator**
   - Built using HTML, CSS, and JavaScript.
   - Supports all arithmetic operations and includes keyboard input.

3. **Portfolio Website**
   - A personal portfolio to showcase skills, projects, and contact info.
   - Includes responsive layout and smooth styling.

4. **Music Player**
   - JavaScript-based audio player with play, pause, next, and previous controls.
   - Includes progress and volume sliders and an interactive playlist.

## 🚀 How to Run

1. Download or clone this repository.
2. Open each folder (`image-gallery`, `calculator`, `portfolio`, `music-player`).
3. Launch the `index.html` file in your web browser to view the project.

## 📂 Folder Structure
```
CodeAlpha_Frontend_Projects/
├── image-gallery/
├── calculator/
├── portfolio/
└── music-player/
```

## 🧾 Credits
Developed as part of the **CodeAlpha Frontend Development Internship**.
